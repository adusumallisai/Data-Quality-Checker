"""
sql_checks.py
--------------
Demonstrates running data-quality checks directly in SQL against a SQLite
database (the same logic could point at MySQL/PostgreSQL/SQL Server with
minor connector changes). This complements the pandas-based checks in
data_quality_checker.py by showing the equivalent SQL approach, which is
often preferred when the dataset lives in a real database and shouldn't
be pulled entirely into memory.

Run:
    python sql_checks.py
"""

import os
import sqlite3

import pandas as pd

DB_PATH = "sample_data/orders.db"
CSV_PATH = "sample_data/customer_orders.csv"


def load_csv_into_sqlite(csv_path: str, db_path: str, table: str = "orders") -> None:
    df = pd.read_csv(csv_path)
    with sqlite3.connect(db_path) as conn:
        df.to_sql(table, conn, if_exists="replace", index=False)
    print(f"Loaded {len(df)} rows into {db_path} (table: {table})")


SQL_CHECKS = {
    "missing_customer_name": """
        SELECT COUNT(*) AS missing_count
        FROM orders
        WHERE customer_name IS NULL OR TRIM(customer_name) = '';
    """,
    "missing_unit_price": """
        SELECT COUNT(*) AS missing_count
        FROM orders
        WHERE unit_price IS NULL;
    """,
    "duplicate_order_ids": """
        SELECT order_id, COUNT(*) AS occurrences
        FROM orders
        GROUP BY order_id
        HAVING COUNT(*) > 1
        ORDER BY occurrences DESC;
    """,
    "invalid_quantity": """
        SELECT order_id, quantity
        FROM orders
        WHERE quantity <= 0 OR quantity > 100;
    """,
    "inconsistent_city_casing": """
        SELECT LOWER(TRIM(city)) AS normalized_city,
               COUNT(DISTINCT city) AS distinct_raw_variants,
               GROUP_CONCAT(DISTINCT city) AS raw_variants_seen
        FROM orders
        WHERE city IS NOT NULL
        GROUP BY normalized_city
        HAVING COUNT(DISTINCT city) > 1;
    """,
    "orders_missing_email": """
        SELECT COUNT(*) AS missing_email
        FROM orders
        WHERE email IS NULL OR TRIM(email) = '';
    """,
}


def run_sql_checks(db_path: str) -> None:
    with sqlite3.connect(db_path) as conn:
        for name, query in SQL_CHECKS.items():
            print(f"\n--- {name} ---")
            result = pd.read_sql_query(query, conn)
            print(result.to_string(index=False))


if __name__ == "__main__":
    if not os.path.exists(CSV_PATH):
        raise SystemExit("Run generate_sample_data.py first to create the sample CSV.")
    load_csv_into_sqlite(CSV_PATH, DB_PATH)
    run_sql_checks(DB_PATH)
