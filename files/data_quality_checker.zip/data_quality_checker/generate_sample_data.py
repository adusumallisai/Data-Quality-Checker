"""
generate_sample_data.py
------------------------
Creates a deliberately messy 'customer_orders' dataset so the Data Quality
Checker has real issues to detect: missing values, duplicate rows,
inconsistent text casing/whitespace, inconsistent date formats, and
out-of-range values.

Run:
    python generate_sample_data.py
Output:
    sample_data/customer_orders.csv
"""

import os
import random
import numpy as np
import pandas as pd

random.seed(42)
np.random.seed(42)

OUTPUT_DIR = "sample_data"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "customer_orders.csv")

FIRST_NAMES = ["Amit", "Priya", "Rahul", "Sneha", "Vikram", "Anita",
               "Kiran", "Deepa", "Suresh", "Meena"]
LAST_NAMES = ["Sharma", "Verma", "Iyer", "Reddy", "Gupta", "Nair",
              "Kumar", "Rao", "Das", "Joshi"]
CITIES_CLEAN = ["Hyderabad", "Bangalore", "Chennai", "Mumbai", "Pune", "Delhi"]
# messy variants of the same cities to simulate inconsistent entry
CITIES_MESSY = ["hyderabad", " Bangalore", "CHENNAI", "Mumbai ", "delhi", "Pune"]
STATUS_CLEAN = ["Delivered", "Pending", "Cancelled", "Returned"]
STATUS_MESSY = ["delivered", "PENDING", "cancelled ", " Returned", "Delivered"]
DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d-%b-%Y"]


def random_date():
    day = random.randint(1, 28)
    month = random.randint(1, 12)
    year = 2025
    fmt = random.choice(DATE_FORMATS)
    return pd.Timestamp(year=year, month=month, day=day).strftime(fmt)


def build_row(order_id, customer_id):
    name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
    city = random.choice(CITIES_CLEAN + CITIES_MESSY)
    status = random.choice(STATUS_CLEAN + STATUS_MESSY)
    qty = random.randint(1, 10)
    price = round(random.uniform(50, 5000), 2)

    # inject occasional bad values
    if random.random() < 0.06:
        qty = -abs(qty)                     # invalid negative quantity
    if random.random() < 0.05:
        price = None                        # missing price
    if random.random() < 0.05:
        name = None                         # missing name
    if random.random() < 0.04:
        city = None                         # missing city
    if random.random() < 0.03:
        qty = 999                           # unrealistic outlier

    return {
        "order_id": order_id,
        "customer_id": customer_id,
        "customer_name": name,
        "city": city,
        "order_date": random_date(),
        "status": status,
        "quantity": qty,
        "unit_price": price,
        "email": f"{name.lower().replace(' ', '.')}@example.com" if name else None,
    }


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    rows = []
    for i in range(1, 501):
        customer_id = random.randint(1000, 1150)  # small pool -> repeat customers
        rows.append(build_row(order_id=i, customer_id=customer_id))

    df = pd.DataFrame(rows)

    # inject exact duplicate rows
    dupes = df.sample(15, random_state=1)
    df = pd.concat([df, dupes], ignore_index=True)

    # inject duplicate order_ids with different data (a nastier duplicate type)
    near_dupes = df.sample(8, random_state=2).copy()
    near_dupes["unit_price"] = near_dupes["unit_price"].fillna(0) + 1
    df = pd.concat([df, near_dupes], ignore_index=True)

    df = df.sample(frac=1, random_state=3).reset_index(drop=True)  # shuffle
    df.to_csv(OUTPUT_FILE, index=False)
    print(f"Sample data written to {OUTPUT_FILE} ({len(df)} rows)")


if __name__ == "__main__":
    main()
