"""
run_example.py
----------------
End-to-end demo of the Data Quality Checker:
  1. Loads the sample CSV
  2. Runs all checks (missing values, duplicates, inconsistent text/dates,
     out-of-range values)
  3. Prints a summary report to the console
  4. Saves the report to reports/summary_report.md
  5. Saves a cleaned version of the dataset to reports/cleaned_orders.csv

Run:
    python generate_sample_data.py   # creates sample_data/customer_orders.csv
    python run_example.py
"""

import os

from data_quality_checker import DataQualityChecker, RangeRule

CSV_PATH = "sample_data/customer_orders.csv"
REPORT_PATH = "reports/summary_report.md"
CLEANED_PATH = "reports/cleaned_orders.csv"


def main():
    if not os.path.exists(CSV_PATH):
        raise SystemExit("Sample data not found. Run 'python generate_sample_data.py' first.")

    dqc = DataQualityChecker.from_csv(CSV_PATH, name="customer_orders.csv")

    dqc.run_all_checks(
        key_column="order_id",
        text_columns=["city", "status"],
        date_column="order_date",
        range_rules=[
            RangeRule(column="quantity", min_value=1, max_value=100),
            RangeRule(column="unit_price", min_value=0, max_value=100000),
        ],
    )

    print(dqc.report())
    dqc.export_report(REPORT_PATH)

    cleaned_df = dqc.clean(
        key_column="order_id",
        text_columns=["city", "status"],
        drop_missing_in=["customer_name"],
    )
    os.makedirs(os.path.dirname(CLEANED_PATH), exist_ok=True)
    cleaned_df.to_csv(CLEANED_PATH, index=False)
    print(f"\nCleaned dataset saved to {CLEANED_PATH} "
          f"({len(cleaned_df)} rows, down from {dqc.total_rows})")


if __name__ == "__main__":
    main()
