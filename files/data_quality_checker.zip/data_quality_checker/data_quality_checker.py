"""
data_quality_checker.py
------------------------
A reusable Data Quality Checker for tabular datasets (CSV or SQL tables).

Detects:
    * Missing / null values (per column, with %)
    * Fully duplicated rows
    * Duplicate keys (e.g. same order_id appearing more than once)
    * Inconsistent text formatting (case, leading/trailing whitespace)
    * Inconsistent date formats within a single date column
    * Out-of-range / invalid numeric values (via user-supplied rules)

Produces:
    * A structured summary report (console table + Markdown/CSV export)
    * An optional "cleaned" version of the dataset

Author: (your name)
"""

from __future__ import annotations

import os
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Optional

import numpy as np
import pandas as pd
from tabulate import tabulate


# --------------------------------------------------------------------------- #
# Data structures
# --------------------------------------------------------------------------- #

@dataclass
class RangeRule:
    """A validation rule: column values must fall within [min_value, max_value]."""
    column: str
    min_value: Optional[float] = None
    max_value: Optional[float] = None


@dataclass
class QualityIssue:
    """A single detected data-quality issue, used to build the summary report."""
    check: str
    column: str
    issue_count: int
    total_rows: int
    detail: str = ""

    @property
    def pct(self) -> float:
        return round(100 * self.issue_count / self.total_rows, 2) if self.total_rows else 0.0


# --------------------------------------------------------------------------- #
# Core checker
# --------------------------------------------------------------------------- #

class DataQualityChecker:
    """
    Load a dataset once, then run individual checks or `run_all_checks()`.

    Example
    -------
    >>> dqc = DataQualityChecker.from_csv("sample_data/customer_orders.csv")
    >>> dqc.check_missing_values()
    >>> dqc.check_duplicate_rows()
    >>> dqc.check_duplicate_keys("order_id")
    >>> dqc.check_inconsistent_text(["city", "status"])
    >>> dqc.check_inconsistent_dates("order_date")
    >>> dqc.check_value_ranges([RangeRule("quantity", min_value=1, max_value=100)])
    >>> print(dqc.report())
    >>> dqc.export_report("reports/summary.md")
    """

    def __init__(self, df: pd.DataFrame, name: str = "dataset"):
        self.df = df.copy()
        self.name = name
        self.total_rows = len(df)
        self.issues: list[QualityIssue] = []

    # ---- constructors ---------------------------------------------------- #

    @classmethod
    def from_csv(cls, path: str, name: Optional[str] = None, **read_csv_kwargs) -> "DataQualityChecker":
        df = pd.read_csv(path, **read_csv_kwargs)
        return cls(df, name=name or os.path.basename(path))

    @classmethod
    def from_sql(cls, db_path: str, query: str, name: str = "sql_query") -> "DataQualityChecker":
        """Load data by running a SQL query against a SQLite database."""
        with sqlite3.connect(db_path) as conn:
            df = pd.read_sql_query(query, conn)
        return cls(df, name=name)

    # ---- individual checks ------------------------------------------------ #

    def check_missing_values(self) -> pd.DataFrame:
        """Report count and percentage of missing (NaN/None/empty-string) values per column."""
        missing_counts = self.df.isna().sum() + self.df.apply(
            lambda col: (col.astype(str).str.strip() == "").sum() if col.dtype == object else 0
        )
        result_rows = []
        for col, count in missing_counts.items():
            if count > 0:
                self.issues.append(QualityIssue(
                    check="Missing Values", column=col,
                    issue_count=int(count), total_rows=self.total_rows,
                ))
            result_rows.append({"column": col, "missing_count": int(count),
                                 "missing_pct": round(100 * count / self.total_rows, 2)})
        return pd.DataFrame(result_rows)

    def check_duplicate_rows(self) -> pd.DataFrame:
        """Report fully duplicated rows (every column identical)."""
        dup_mask = self.df.duplicated(keep=False)
        dup_count = int(self.df.duplicated(keep="first").sum())
        if dup_count > 0:
            self.issues.append(QualityIssue(
                check="Duplicate Rows", column="(all columns)",
                issue_count=dup_count, total_rows=self.total_rows,
                detail="Exact duplicate rows (keeping first occurrence as valid)",
            ))
        return self.df[dup_mask].sort_values(by=list(self.df.columns))

    def check_duplicate_keys(self, key_column: str) -> pd.DataFrame:
        """Report values in `key_column` that appear more than once (e.g. duplicate IDs)."""
        counts = self.df[key_column].value_counts()
        dup_keys = counts[counts > 1]
        dup_count = int(dup_keys.sum() - len(dup_keys))  # extra occurrences beyond the first
        if dup_count > 0:
            self.issues.append(QualityIssue(
                check="Duplicate Key", column=key_column,
                issue_count=dup_count, total_rows=self.total_rows,
                detail=f"{len(dup_keys)} distinct '{key_column}' values repeated",
            ))
        return self.df[self.df[key_column].isin(dup_keys.index)].sort_values(key_column)

    def check_inconsistent_text(self, columns: list[str]) -> pd.DataFrame:
        """
        Flag categorical/text columns where the same logical value appears in
        multiple forms (casing, leading/trailing whitespace) — e.g.
        'Bangalore', 'bangalore', ' Bangalore' all being treated as different.
        """
        summary_rows = []
        for col in columns:
            if col not in self.df.columns:
                continue
            series = self.df[col].dropna().astype(str)
            normalized = series.str.strip().str.lower()
            raw_variants = series.unique()
            norm_variants = normalized.unique()

            inconsistent_count = len(raw_variants) - len(norm_variants)

            # For each normalized group, the "canonical" raw form is whichever
            # raw spelling occurs most often; any row not matching that raw
            # form (different case/whitespace) counts as a mismatch.
            canonical_map = (
                series.groupby(normalized)
                .agg(lambda vals: vals.value_counts().idxmax())
            )
            canonical_per_row = normalized.map(canonical_map)
            mismatch_rows = int((series != canonical_per_row).sum())

            if inconsistent_count > 0 or mismatch_rows > 0:
                self.issues.append(QualityIssue(
                    check="Inconsistent Text Formatting", column=col,
                    issue_count=mismatch_rows, total_rows=self.total_rows,
                    detail=f"{inconsistent_count} distinct values collapse into fewer once "
                           f"trimmed/lower-cased (e.g. casing or whitespace differences)",
                ))
            summary_rows.append({
                "column": col,
                "raw_unique_values": len(raw_variants),
                "normalized_unique_values": len(norm_variants),
                "rows_with_case_or_whitespace_issues": mismatch_rows,
            })
        return pd.DataFrame(summary_rows)

    def check_inconsistent_dates(self, column: str,
                                  candidate_formats: Optional[list[str]] = None) -> pd.DataFrame:
        """
        Flag a date column where values are stored in more than one format
        (e.g. mixing 'YYYY-MM-DD', 'DD/MM/YYYY', 'DD-Mon-YYYY').
        """
        candidate_formats = candidate_formats or ["%Y-%m-%d", "%d/%m/%Y", "%d-%b-%Y", "%m/%d/%Y"]

        def detect_format(value):
            if pd.isna(value):
                return None
            value = str(value).strip()
            for fmt in candidate_formats:
                try:
                    datetime.strptime(value, fmt)
                    return fmt
                except ValueError:
                    continue
            return "UNRECOGNIZED"

        formats_detected = self.df[column].apply(detect_format)
        format_counts = formats_detected.value_counts(dropna=True)
        distinct_formats = [f for f in format_counts.index if f is not None]

        if len(distinct_formats) > 1:
            issue_count = int(self.total_rows - format_counts.max())
            self.issues.append(QualityIssue(
                check="Inconsistent Date Format", column=column,
                issue_count=issue_count, total_rows=self.total_rows,
                detail=f"Formats found: {', '.join(distinct_formats)}",
            ))
        return format_counts.rename_axis("detected_format").reset_index(name="row_count")

    def check_value_ranges(self, rules: list[RangeRule]) -> pd.DataFrame:
        """Flag numeric values outside an expected [min, max] range."""
        summary_rows = []
        for rule in rules:
            if rule.column not in self.df.columns:
                continue
            col = pd.to_numeric(self.df[rule.column], errors="coerce")
            mask = pd.Series(False, index=col.index)
            if rule.min_value is not None:
                mask |= col < rule.min_value
            if rule.max_value is not None:
                mask |= col > rule.max_value
            bad_count = int(mask.sum())
            if bad_count > 0:
                self.issues.append(QualityIssue(
                    check="Out-of-Range Value", column=rule.column,
                    issue_count=bad_count, total_rows=self.total_rows,
                    detail=f"Expected range [{rule.min_value}, {rule.max_value}]",
                ))
            summary_rows.append({"column": rule.column, "invalid_count": bad_count,
                                  "expected_min": rule.min_value, "expected_max": rule.max_value})
        return pd.DataFrame(summary_rows)

    # ---- convenience: run everything -------------------------------------- #

    def run_all_checks(self, key_column: Optional[str] = None,
                        text_columns: Optional[list[str]] = None,
                        date_column: Optional[str] = None,
                        range_rules: Optional[list[RangeRule]] = None) -> None:
        self.check_missing_values()
        self.check_duplicate_rows()
        if key_column:
            self.check_duplicate_keys(key_column)
        if text_columns:
            self.check_inconsistent_text(text_columns)
        if date_column:
            self.check_inconsistent_dates(date_column)
        if range_rules:
            self.check_value_ranges(range_rules)

    # ---- reporting ---------------------------------------------------- #

    def report(self) -> str:
        """Return a human-readable summary table of every issue found so far."""
        if not self.issues:
            return f"No data quality issues detected in '{self.name}'."
        rows = [
            {"Check": i.check, "Column": i.column, "Issue Count": i.issue_count,
             "% of Rows": i.pct, "Detail": i.detail}
            for i in self.issues
        ]
        header = f"Data Quality Report: {self.name}  ({self.total_rows} rows total)\n"
        return header + tabulate(rows, headers="keys", tablefmt="github")

    def export_report(self, path: str) -> None:
        """Write the summary report to a Markdown (.md) or CSV (.csv) file."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        if path.endswith(".csv"):
            pd.DataFrame([i.__dict__ | {"pct": i.pct} for i in self.issues]).to_csv(path, index=False)
        else:
            with open(path, "w") as f:
                f.write(self.report())
        print(f"Report saved to {path}")

    # ---- cleaning ---------------------------------------------------- #

    def clean(self, key_column: Optional[str] = None,
              text_columns: Optional[list[str]] = None,
              drop_missing_in: Optional[list[str]] = None) -> pd.DataFrame:
        """
        Return a cleaned copy of the dataset:
          * drops fully duplicated rows
          * drops extra rows sharing a duplicate key (keeps first)
          * trims whitespace and standardizes casing in text_columns
          * optionally drops rows missing required fields
        """
        cleaned = self.df.drop_duplicates()
        if key_column:
            cleaned = cleaned.drop_duplicates(subset=[key_column], keep="first")
        if text_columns:
            for col in text_columns:
                if col in cleaned.columns:
                    cleaned[col] = cleaned[col].astype(str).str.strip().str.title()
        if drop_missing_in:
            cleaned = cleaned.dropna(subset=drop_missing_in)
        return cleaned.reset_index(drop=True)
