Data Quality Report: customer_orders.csv  (523 rows total)
| Check                        | Column        |   Issue Count |   % of Rows | Detail                                                                                                 |
|------------------------------|---------------|---------------|-------------|--------------------------------------------------------------------------------------------------------|
| Missing Values               | customer_name |            24 |        4.59 |                                                                                                        |
| Missing Values               | city          |            17 |        3.25 |                                                                                                        |
| Missing Values               | unit_price    |            14 |        2.68 |                                                                                                        |
| Missing Values               | email         |            24 |        4.59 |                                                                                                        |
| Duplicate Rows               | (all columns) |            15 |        2.87 | Exact duplicate rows (keeping first occurrence as valid)                                               |
| Duplicate Key                | order_id      |            23 |        4.4  | 23 distinct 'order_id' values repeated                                                                 |
| Inconsistent Text Formatting | city          |           185 |       35.37 | 5 distinct values collapse into fewer once trimmed/lower-cased (e.g. casing or whitespace differences) |
| Inconsistent Text Formatting | status        |           228 |       43.59 | 4 distinct values collapse into fewer once trimmed/lower-cased (e.g. casing or whitespace differences) |
| Inconsistent Date Format     | order_date    |           327 |       62.52 | Formats found: %d-%b-%Y, %d/%m/%Y, %Y-%m-%d                                                            |
| Out-of-Range Value           | quantity      |            45 |        8.6  | Expected range [1, 100]                                                                                |